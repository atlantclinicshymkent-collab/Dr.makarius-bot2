// api/cron.js
import { sendMessage } from "../lib/telegram.js";
import {
  getLastHealth,
  getWeekWorkouts,
  getTodayCalories,
  ping,
} from "../lib/supabase.js";

export default async function handler(req, res) {
  // Перевірка автентифікації cron
  const authHeader = req.headers["authorization"];
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const chatId = process.env.TELEGRAM_CHAT_ID;

  try {
    // Пінг Supabase (keep alive)
    await ping();

    // Зібрати дані для брифінгу
    const health = await getLastHealth();
    const workouts = await getWeekWorkouts();

    const lines = ["☀️ *Доброго ранку, Макар!*", ""];

    // Здоров'я
    if (health) {
      lines.push("🏥 *Здоров'я:*");
      if (health.resting_hr) lines.push(`  ❤️ Пульс: ${health.resting_hr} уд/хв`);
      if (health.hrv) lines.push(`  📊 HRV: ${health.hrv} мс`);
      if (health.sleep_hours) lines.push(`  😴 Сон: ${health.sleep_hours} год`);
      if (health.recovery_pct) lines.push(`  🔋 Відновлення: ${health.recovery_pct}%`);

      // Рекомендація
      if (health.recovery_pct) {
        lines.push("");
        if (health.recovery_pct >= 70) {
          lines.push("💪 Організм відновився — можна тренуватися інтенсивно!");
        } else if (health.recovery_pct >= 40) {
          lines.push("⚡ Помірне відновлення — легке тренування або техніка.");
        } else {
          lines.push("🛌 Відновлення низьке — краще відпочити сьогодні.");
        }
      }
    } else {
      lines.push("📭 Немає даних про здоров'я. Надішли скріншот COROS!");
    }

    lines.push("");

    // Тренування за тиждень
    if (workouts.length > 0) {
      const totalKm = workouts.reduce((s, w) => s + (Number(w.distance_km) || 0), 0);
      lines.push(`🏃 *Тиждень:* ${workouts.length} тренувань, ${totalKm.toFixed(1)} км`);
    }

    lines.push("");
    lines.push("📸 _Надішли скріншот COROS для оновлення даних_");

    await sendMessage(chatId, lines.join("\n"));
  } catch (err) {
    console.error("Cron error:", err);
  }

  return res.status(200).json({ ok: true });
}
