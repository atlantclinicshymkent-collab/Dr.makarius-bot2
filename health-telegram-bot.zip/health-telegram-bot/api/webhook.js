// api/webhook.js
import { handlePhoto } from "../lib/vision.js";
import { handleCommand } from "../lib/commands.js";
import { sendMessage } from "../lib/telegram.js";

const ALLOWED_ID = process.env.TELEGRAM_CHAT_ID;

export default async function handler(req, res) {
  // Telegram sends POST
  if (req.method !== "POST") {
    return res.status(200).json({ ok: true, method: req.method });
  }

  const { message } = req.body || {};
  if (!message) {
    return res.status(200).json({ ok: true, note: "no message" });
  }

  // Безпека: тільки твій Telegram ID
  const chatId = message.chat.id;
  if (String(chatId) !== String(ALLOWED_ID)) {
    console.log(`Blocked: ${chatId}`);
    return res.status(200).end();
  }

  try {
    // Фото = скріншот COROS
    if (message.photo && message.photo.length > 0) {
      await handlePhoto(message, chatId);
    }
    // Текстова команда
    else if (message.text) {
      await handleCommand(message.text, chatId);
    }
  } catch (err) {
    console.error("Webhook error:", err.message || err);
    try {
      await sendMessage(chatId, "⚠️ Щось пішло не так. Спробуй ще раз.");
    } catch (_) {
      // ignore send error
    }
  }

  return res.status(200).json({ ok: true });
}
